package lab3.zad4;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Line implements Shape{
    private List<Point> points = new ArrayList<>();

    public void addPoint(Point point) {
        points.add(point);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        for (int i = 0; i < points.size() - 1; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            g.drawLine(p1.getX(), p1.getY(), p2.getX(), p2.getY());
        }
    }
}
