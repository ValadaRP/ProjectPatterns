package lab3.zad4;

import java.awt.*;

public interface Shape {
    void draw(Graphics g);
}
