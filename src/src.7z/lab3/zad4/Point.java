package lab3.zad4;

import zad5.Circle;

import java.awt.*;

public class Point implements Shape{
    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillOval(x - 2, y - 2, 5, 5);
    }
}
