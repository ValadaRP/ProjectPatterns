package lab3.zad4;

import java.awt.*;

public class Cube implements Shape{
    private int x;
    private int y;
    private int width;
    private int height;
    private int depth;

    public Cube(int x, int y, int width, int height, int depth) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.depth = depth;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.GREEN);

        // Rysowanie ścian bocznych
        g.fillRect(x, y, width, height);
        g.fillRect(x + width, y + height, depth, height);
        g.fillRect(x, y + height, width, depth);

        // Rysowanie ścian górnej i dolnej
        g.setColor(Color.YELLOW);
        g.fillRect(x, y, width, depth);
        g.fillRect(x, y + height + depth, width + depth, depth);

        // Rysowanie ścian przedniej i tylnej
        g.setColor(Color.ORANGE);
        g.fillRect(x, y, depth, height + depth);
        g.fillRect(x + width, y, depth, height + depth);
    }
}
