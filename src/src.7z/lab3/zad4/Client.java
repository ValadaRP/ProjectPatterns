package lab3.zad4;

import javax.swing.*;

public class Client {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Drawing Shapes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        DrawingPanel drawingPanel = new DrawingPanel();

        // Dodawanie punktu
        Point point = new Point(100, 100);
        drawingPanel.addShape(point);

        // Dodawanie linii
        Line line = new Line();
        line.addPoint(new Point(50, 50));
        line.addPoint(new Point(150, 150));
        drawingPanel.addShape(line);

        // Dodawanie prostokąta
        Rectangle rectangle = new Rectangle(200, 200, 100, 50);
        drawingPanel.addShape(rectangle);

        // Dodawanie sześcianu
        Cube cube = new Cube(300, 300, 100, 100, 20);
        drawingPanel.addShape(cube);

        frame.add(drawingPanel);
        frame.setSize(500, 500);
        frame.setVisible(true);
    }
}
