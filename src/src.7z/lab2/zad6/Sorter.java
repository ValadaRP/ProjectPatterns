package lab2.zad6;

public interface Sorter {
    void sortuj();
}
