package lab2.zad6;

public class ArrayTextStorage extends TextStorage{
    private String[] texts;

    @Override
    public Sorter createSorter() {
        return new ArraySorter();
    }
}
