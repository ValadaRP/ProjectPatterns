package lab2.zad6;

public abstract class TextStorage {
    public abstract Sorter createSorter();
}
